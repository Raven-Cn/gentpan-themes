<?php get_header(); ?>
	<main>
		<div class="Qb Rb J Sb Fb Tb">
			<div class="m kb" style="text-align: center;">
				<h1>404 - 你要查找的页面没找到哦！</h1>
				请检查下是否输入网址有误哦，或者重新搜索试试呢？说不定还在！
			</div>
		</div>
	</main>
	 </div>
<?php get_footer(); ?>